import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import initial_values from '../initial_values.json';
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {

  
  public List:{name:string, email:string, feedback:string, comment:string}[] = initial_values;
  name1= new FormControl(initial_values.name);
  email1= new FormControl(initial_values.email);
  comment1=new FormControl(initial_values.comment);

  form: FormGroup;
  constructor(fb: FormBuilder) {

    this.form = fb.group({
      feedback1: [initial_values.feedback, Validators.required]
    });
  }
  ngOnInit(): void {
  }
}
