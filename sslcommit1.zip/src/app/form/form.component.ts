import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import initial_values from '../initial_values.json';
import { HttpClient } from '@angular/common/http'; 
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {

  items=[];
  form: FormGroup;
  radioItems= 'Great,Okay,Not good'.split(',');
  model;
  public List:{name:string, email:string, feedback:string, comment:string}[] = initial_values;
  
  constructor(private http: HttpClient, fb: FormBuilder) {
    
    this.http.get('https://cs251-outlab-6.herokuapp.com/initial_values/').toPromise().then(data => {console.log(data);
      for (let key in data){
        if (data.hasOwnProperty(key))
          this.items.push(data[key]);
        if (key=="feedback")
          this.model= { options: data[key] };
      }
   });
    
   
    this.form = fb.group({
      feedback1: [this.items[2], Validators.required]
    });    
    
  }
  ngOnInit(): void {
    
    
  }
  
}

