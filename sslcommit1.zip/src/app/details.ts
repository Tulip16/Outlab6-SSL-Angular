export interface details {
    name: string;
    email: string;
    comment: string;
    feedback:string;
}